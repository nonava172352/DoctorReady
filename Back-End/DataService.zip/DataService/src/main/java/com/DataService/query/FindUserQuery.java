package com.DataService.query;

public class FindUserQuery {

}
