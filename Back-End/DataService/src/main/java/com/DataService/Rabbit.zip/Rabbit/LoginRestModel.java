package com.DataService.Rabbit;

import lombok.Data;

import java.io.Serializable;
@Data
public class LoginRestModel  {
    private String username;
    private String password;

}
